﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JogoChrome
{
    public partial class Form1 : Form
    {

        private int velocidade_chao = 7;
        private int altura_pulo = 200;
        private int velocidade_pulo;
        private int posicaoY_atual_dino;
        private int velocidade_cacto = 7;
        private int c;
        private int gera_pos;
        private int pontos = 0;
        int starta = 0;

        private bool postura_dino = true;
        private bool atualiza_IMG_dino = true;
        private bool verifica_pode_pular = true;
        private bool dino_pulando = false;
        private bool seta_pressionada = false;
        private bool pode_passaro = true;
        private bool atualiza_IMG_passaro = true;

        double[][] matriz_velocidade = new double[20][];
        string[] posicoes_dino = new string[6];
        string[] objetos = new string[6];



        public Form1()
        {
            InitializeComponent();

            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.Size = new Size(900, 500);

            Random random = new Random();
            int top = random.Next(0, 250);
            int left = random.Next(900, 2500);
            pb_nuvem_1.Left = left;
            pb_nuvem_1.Top = top;
            top = random.Next(0, 250);
            left = random.Next(900, 2500);
            pb_nuvem_2.Left = left;
            pb_nuvem_2.Top = top;
            top = random.Next(0, 250);
            left = random.Next(900, 2500);
            pb_nuvem_3.Left = left;
            pb_nuvem_3.Top = top;

            Random numRandom = new Random();
            int gera_pos =  numRandom.Next(1000, 1500);
            pbCacto.Left = gera_pos;
            pb_passaro.Left = gera_pos+500;
            gera_pos = numRandom.Next(1000, 1500);
            pbCacto2.Left = gera_pos;




            pbchao_2.Left = pbchao_1.Left + pbchao_1.Width;

            timer_velocidade_chao.Enabled = true;
            timer_nuvens.Enabled = true;
            timer_passaros.Enabled = true;
            pb_dino_pe.Visible = true;
            posicaoY_atual_dino = pb_dino_pe.Top;
            Cactos.Enabled = true;

            contador.Enabled = true;

            //######## MATRIZ QUE VAI CONTROLAR A VELOCIDADE DE SUBIDA ###########//

            matriz_velocidade[0] = new double[] { 1.1, 10 };
            matriz_velocidade[1] = new double[] { 1.3, 10 };
            matriz_velocidade[2] = new double[] { 1.5, 10 };
            matriz_velocidade[3] = new double[] { 1.7, 14 };
            matriz_velocidade[4] = new double[] { 1.9, 16 };
            matriz_velocidade[5] = new double[] { 2, 17 };
            matriz_velocidade[6] = new double[] { 4, 19 };
            matriz_velocidade[7] = new double[] { 6, 21 };
            matriz_velocidade[8] = new double[] { 8, 22 };
            matriz_velocidade[9] = new double[] { 10, 24 };
            matriz_velocidade[10] = new double[] { 11, 26 };
            matriz_velocidade[11] = new double[] { 12, 28 };
            matriz_velocidade[12] = new double[] { 13, 30 };
            matriz_velocidade[13] = new double[] { 14, 33 };
            matriz_velocidade[14] = new double[] { 15, 34 };

            //#####################################################################//

            //################ DIRETORIO DAS IMAGENS DO DINOSSAURO ################//

            posicoes_dino[0] = "../../../../Nova pasta/dino_pe_perna1.png";
            posicoes_dino[1] = "../../../../Nova pasta/dino_pe_perna2.png";
            posicoes_dino[2] = "../../../../Nova pasta/dino_abaixado_1.png";
            posicoes_dino[3] = "../../../../Nova pasta/dino_abaixado_2.png";
            posicoes_dino[4] = "../../../../Nova pasta/dino_pe_reto.png";
            posicoes_dino[5] = "../../../../Nova pasta/dino_morto.png";

            //#####################################################################//



            //################ DIRETORIO DAS IMAGENS DOS CACTOS ################//

            objetos[0] = "../../../../Nova pasta/cacto_com_1.png";
            objetos[1] = "../../../../Nova pasta/cacto_com_1_pequeno.png";
            objetos[2] = "../../../../Nova pasta/cacto_com_2.png";
            objetos[3] = "../../../../Nova pasta/cacto_com_2_pequeno.png";
            objetos[4] = "../../../../Nova pasta/cacto_com_3.png";
            objetos[5] = "../../../../Nova pasta/cacto_com_3_pequeno.png";

            //#####################################################################//


        }

        private void colisao(PictureBox pictureBox_dino, PictureBox pictureBox_objeto, int valor) {

            if (pictureBox_dino.Location.X >= pictureBox_objeto.Location.X - pictureBox_objeto.Size.Width + valor && pictureBox_dino.Location.X <= pictureBox_objeto.Location.X + pictureBox_objeto.Size.Width - valor && pictureBox_dino.Location.Y >= pictureBox_objeto.Location.Y - pictureBox_objeto.Size.Height + valor && pictureBox_dino.Location.Y <= pictureBox_objeto.Location.Y + pictureBox_objeto.Size.Height - valor)
            {
                timer_velocidade_chao.Enabled = false;
                timer_movimento_dino.Enabled = false;
                timer_pulo.Enabled = false; 
                timer_descer.Enabled = false;
                timer_parado_alto.Enabled = false;
                Cactos.Enabled = false;
                contador.Enabled = false;
                timer_colisao.Enabled = false;
                timer_nuvens.Enabled = false;
                timer_passaros.Enabled = false;

                pb_restart.Visible = true;
                starta = 1;
                pb_restart.Load("../../../../Nova pasta/start.png");

            }

        }

        private void start() {

        
        }

        private void atualizaImagem(PictureBox pictureBox, string imagem) {

             pictureBox.Load(imagem);

        }

        private void movimenta_imagem(PictureBox pbBox, int velocidade) {

            pbBox.Left -= velocidade;
        
        }


        private void timer_velocidade_chao_Tick(object sender, EventArgs e)
        {

            movimenta_imagem(pbchao_1,velocidade_chao);
            movimenta_imagem(pbchao_2, velocidade_chao);
    
            if (pbchao_1.Left + pbchao_1.Width < 0)
            {

                pbchao_1.Left = pbchao_2.Left + pbchao_2.Width;

            }

            if (pbchao_2.Left + pbchao_2.Width < 0)
            {

                pbchao_2.Left = pbchao_1.Left + pbchao_1.Width;

            }

        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Down)
            {
                if (pb_dino_pe.Top == posicaoY_atual_dino && (verifica_pode_pular))
                {

                    postura_dino = false;
                    seta_pressionada = true;

                }
                else {

                    verifica_pode_pular = false;
                    dino_pulando = true;
                    timer_pulo.Enabled = false;
                    timer_descer.Enabled = true;

                }


            }

            if (!seta_pressionada) {
                
                if ((e.KeyCode == Keys.Space) || (e.KeyCode == Keys.Up))
                {

                    if (verifica_pode_pular) {

                        atualizaImagem(pb_dino_pe, posicoes_dino[4]);
                        posicaoY_atual_dino = pb_dino_pe.Top;
                        verifica_pode_pular = false;
                        dino_pulando = true;
                        timer_pulo.Enabled = true;
                
                    }

                }

            }

        }

        //private void Form1_KeyPress(object sender, KeyPressEventArgs e)
        //{
        //}

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Down)
            {

                postura_dino = true;
                seta_pressionada = false;

            }

            if ((e.KeyCode == Keys.Space) || (e.KeyCode == Keys.Up))
            {
                if (dino_pulando && (pb_dino_pe.Top <= (posicaoY_atual_dino - altura_pulo))){

                    verifica_pode_pular = false;
                    dino_pulando = true;
                    timer_pulo.Enabled = false;
                    timer_parado_alto.Enabled = true;


                }

            }
        }

        private void timer_movimento_dino_Tick(object sender, EventArgs e)
        {
            if (!dino_pulando) { 

                if (postura_dino)
                {

                    pb_dino_pe.Visible = true;
                    pb_dino_abaixado.Visible = false;
                    pb_dino_abaixado.Enabled = false;

                    if (atualiza_IMG_dino) {

                        atualizaImagem(pb_dino_pe, posicoes_dino[0]);
                        atualiza_IMG_dino = !atualiza_IMG_dino;

                    }
                    else {

                        atualizaImagem(pb_dino_pe, posicoes_dino[1]);
                        atualiza_IMG_dino = !atualiza_IMG_dino;

                    }

                }

                if (!postura_dino)
                {

                    pb_dino_pe.Visible = false;
                    pb_dino_abaixado.Visible = true;
                    pb_dino_abaixado.Enabled = true;

                    if (atualiza_IMG_dino)
                    {

                        atualizaImagem(pb_dino_abaixado, posicoes_dino[2]);
                        atualiza_IMG_dino = !atualiza_IMG_dino;

                    }
                    else
                    {

                        atualizaImagem(pb_dino_abaixado, posicoes_dino[3]);
                        atualiza_IMG_dino = !atualiza_IMG_dino;

                    }

                }

            }

            if (pode_passaro) {

                if (atualiza_IMG_passaro)
                {

                    atualizaImagem(pb_passaro, "../../../../Nova pasta/passaro_2.png");
                    atualiza_IMG_passaro = !atualiza_IMG_passaro;

                }
                else
                {

                    atualizaImagem(pb_passaro, "../../../../Nova pasta/passaro_1.png");
                    atualiza_IMG_passaro = !atualiza_IMG_passaro;

                }

            }

        }

        private void timer_pulo_Tick(object sender, EventArgs e)
        {

            for (int i = 0; i < 15; i++)
            {

                if (pb_dino_pe.Top > (int)(posicaoY_atual_dino - (altura_pulo / matriz_velocidade[i][0])))
                {

                    velocidade_pulo = (int)matriz_velocidade[i][1];

                }

            }

            pb_dino_pe.Top -= velocidade_pulo;

            if (pb_dino_pe.Top <= posicaoY_atual_dino - altura_pulo) { 

                timer_pulo.Enabled = false;
                timer_parado_alto.Enabled = true;
             
            }
            
        }
        private void timer_parado_alto_Tick(object sender, EventArgs e)
        {
            timer_descer.Enabled = true;
            timer_parado_alto.Enabled = false;

        }

        private void timer_descer_Tick(object sender, EventArgs e)
        {

            for (int i = 10; i < 15; i++)
            {

                if (pb_dino_pe.Top > (int)(posicaoY_atual_dino - (altura_pulo / matriz_velocidade[i][0])))
                {

                    velocidade_pulo = (int)matriz_velocidade[i][1];

                }

            }

            pb_dino_pe.Top += velocidade_pulo;

            if (pb_dino_pe.Top >= posicaoY_atual_dino)
            {
                pb_dino_pe.Top = posicaoY_atual_dino;
                verifica_pode_pular = true;
                dino_pulando = false;
                timer_descer.Enabled = false;
            }

        }

        private void Cactos_Tick(object sender, EventArgs e)
        {

            pbCacto.Left -= velocidade_cacto;
            pbCacto2.Left -= velocidade_cacto;
            Random numRandom = new Random();
            c = numRandom.Next(0, 5);
            gera_pos = 1000 + numRandom.Next(400,600);

            if(pbCacto.Left + pbCacto.Width < 0)
            {
                for (int i = 0; i < 6; i++)
                    atualizaImagem(pbCacto, objetos[c]);
                
                    pbCacto.Left = 900;

                if (Math.Abs(pbCacto.Left - pbCacto2.Left) < 200) {

                    pbCacto.Left = pbCacto.Left + 200;
                }

            }

            if (pbCacto2.Left + pbCacto2.Width < 0)
            {
                for (int i = 0; i < 6; i++)                  
                atualizaImagem(pbCacto2, objetos[c]);

                pbCacto2.Left = gera_pos;

                if (Math.Abs(pbCacto.Left - pbCacto2.Left) < 200 )
                {

                    pbCacto2.Left = pbCacto2.Left + 200;
                }

            }

        }

        private void contador_Tick(object sender, EventArgs e)
        {

            pontos++;
            label1.Text = pontos.ToString();

                
        }

        private void recomeca_Click(object sender, EventArgs e)
        {
            timer_movimento_dino.Enabled = true;
            timer_velocidade_chao.Enabled = true;
            contador.Enabled = true;
            Application.Restart();
            Environment.Exit(0);
        }

        private void timer_colisao_Tick(object sender, EventArgs e)
        {
            if (postura_dino) { 

                int valor = 50;
                colisao(pb_dino_pe,pbCacto,valor);
                colisao(pb_dino_pe, pbCacto2, valor);
                colisao(pb_dino_pe, pb_passaro, 10);
            }
            if (!postura_dino)
            {

                int valor = 50;
                colisao(pb_dino_abaixado, pbCacto, valor);
                colisao(pb_dino_abaixado, pbCacto2, valor);

            }




        }

        private void timer_nuvens_Tick(object sender, EventArgs e)
        {
            movimenta_imagem(pb_nuvem_1, velocidade_chao);
            movimenta_imagem(pb_nuvem_2, velocidade_chao);
            movimenta_imagem(pb_nuvem_3, velocidade_chao);

            Random random = new Random();

            int top = random.Next(0,250);
            int left = random.Next(900, 2500);

            if (pb_nuvem_1.Left + pb_nuvem_1.Width < 0 )
            {
                pb_nuvem_1.Left = left;
                pb_nuvem_1.Top = top;

            }
            if (pb_nuvem_2.Left + pb_nuvem_2.Width < 0)
            {
                pb_nuvem_2.Left = left;
                pb_nuvem_2.Top = top;

            }
            if (pb_nuvem_3.Left + pb_nuvem_3.Width < 0)
            {
                pb_nuvem_3.Left = left;
                pb_nuvem_3.Top = top;

            }

        }

        private void timer_passaros_Tick(object sender, EventArgs e)
        {

            if (pode_passaro) { 

                movimenta_imagem(pb_passaro, velocidade_chao+2);

                Random random = new Random();

                int left = random.Next(1400, 4000);

                if (pb_passaro.Left + pb_passaro.Width < 0)
                {
                    pb_passaro.Left = left;

                }
            }

        }

        private void bate_asa_Tick(object sender, EventArgs e)
        {

        }

        private void pb_restart_Click(object sender, EventArgs e)
        {

            if (starta == 1) {


                Application.Restart();
                // Fecha o formulário atual
                this.Close();

            }

        }
    }
}

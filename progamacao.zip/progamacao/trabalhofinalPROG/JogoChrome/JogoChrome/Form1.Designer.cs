﻿namespace JogoChrome
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.timer_velocidade_chao = new System.Windows.Forms.Timer(this.components);
            this.timer_movimento_dino = new System.Windows.Forms.Timer(this.components);
            this.timer_descer = new System.Windows.Forms.Timer(this.components);
            this.timer_pulo = new System.Windows.Forms.Timer(this.components);
            this.timer_parado_alto = new System.Windows.Forms.Timer(this.components);
            this.Cactos = new System.Windows.Forms.Timer(this.components);
            this.pbchao_1 = new System.Windows.Forms.PictureBox();
            this.pbchao_2 = new System.Windows.Forms.PictureBox();
            this.pb_dino_pe = new System.Windows.Forms.PictureBox();
            this.pb_dino_abaixado = new System.Windows.Forms.PictureBox();
            this.pbCacto = new System.Windows.Forms.PictureBox();
            this.pbCacto2 = new System.Windows.Forms.PictureBox();
            this.contador = new System.Windows.Forms.Timer(this.components);
            this.timer_colisao = new System.Windows.Forms.Timer(this.components);
            this.timer_nuvens = new System.Windows.Forms.Timer(this.components);
            this.pb_nuvem_1 = new System.Windows.Forms.PictureBox();
            this.pb_nuvem_3 = new System.Windows.Forms.PictureBox();
            this.pb_nuvem_2 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pb_passaro = new System.Windows.Forms.PictureBox();
            this.timer_passaros = new System.Windows.Forms.Timer(this.components);
            this.pb_restart = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pbchao_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbchao_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_dino_pe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_dino_abaixado)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCacto)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCacto2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_nuvem_1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_nuvem_3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_nuvem_2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_passaro)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_restart)).BeginInit();
            this.SuspendLayout();
            // 
            // timer_velocidade_chao
            // 
            this.timer_velocidade_chao.Interval = 13;
            this.timer_velocidade_chao.Tick += new System.EventHandler(this.timer_velocidade_chao_Tick);
            // 
            // timer_movimento_dino
            // 
            this.timer_movimento_dino.Enabled = true;
            this.timer_movimento_dino.Interval = 80;
            this.timer_movimento_dino.Tick += new System.EventHandler(this.timer_movimento_dino_Tick);
            // 
            // timer_descer
            // 
            this.timer_descer.Interval = 13;
            this.timer_descer.Tick += new System.EventHandler(this.timer_descer_Tick);
            // 
            // timer_pulo
            // 
            this.timer_pulo.Interval = 13;
            this.timer_pulo.Tick += new System.EventHandler(this.timer_pulo_Tick);
            // 
            // timer_parado_alto
            // 
            this.timer_parado_alto.Interval = 90;
            this.timer_parado_alto.Tick += new System.EventHandler(this.timer_parado_alto_Tick);
            // 
            // Cactos
            // 
            this.Cactos.Interval = 13;
            this.Cactos.Tick += new System.EventHandler(this.Cactos_Tick);
            // 
            // pbchao_1
            // 
            this.pbchao_1.Image = ((System.Drawing.Image)(resources.GetObject("pbchao_1.Image")));
            this.pbchao_1.Location = new System.Drawing.Point(-1547, 350);
            this.pbchao_1.Name = "pbchao_1";
            this.pbchao_1.Size = new System.Drawing.Size(2398, 34);
            this.pbchao_1.TabIndex = 0;
            this.pbchao_1.TabStop = false;
            // 
            // pbchao_2
            // 
            this.pbchao_2.Image = ((System.Drawing.Image)(resources.GetObject("pbchao_2.Image")));
            this.pbchao_2.Location = new System.Drawing.Point(511, 350);
            this.pbchao_2.Name = "pbchao_2";
            this.pbchao_2.Size = new System.Drawing.Size(2398, 34);
            this.pbchao_2.TabIndex = 1;
            this.pbchao_2.TabStop = false;
            // 
            // pb_dino_pe
            // 
            this.pb_dino_pe.Image = ((System.Drawing.Image)(resources.GetObject("pb_dino_pe.Image")));
            this.pb_dino_pe.Location = new System.Drawing.Point(-16, 289);
            this.pb_dino_pe.Name = "pb_dino_pe";
            this.pb_dino_pe.Size = new System.Drawing.Size(93, 69);
            this.pb_dino_pe.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_dino_pe.TabIndex = 2;
            this.pb_dino_pe.TabStop = false;
            this.pb_dino_pe.Visible = false;
            // 
            // pb_dino_abaixado
            // 
            this.pb_dino_abaixado.Image = ((System.Drawing.Image)(resources.GetObject("pb_dino_abaixado.Image")));
            this.pb_dino_abaixado.Location = new System.Drawing.Point(-6, 306);
            this.pb_dino_abaixado.Name = "pb_dino_abaixado";
            this.pb_dino_abaixado.Size = new System.Drawing.Size(100, 50);
            this.pb_dino_abaixado.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_dino_abaixado.TabIndex = 3;
            this.pb_dino_abaixado.TabStop = false;
            this.pb_dino_abaixado.Visible = false;
            // 
            // pbCacto
            // 
            this.pbCacto.Image = ((System.Drawing.Image)(resources.GetObject("pbCacto.Image")));
            this.pbCacto.Location = new System.Drawing.Point(735, 285);
            this.pbCacto.Name = "pbCacto";
            this.pbCacto.Size = new System.Drawing.Size(95, 72);
            this.pbCacto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbCacto.TabIndex = 4;
            this.pbCacto.TabStop = false;
            // 
            // pbCacto2
            // 
            this.pbCacto2.Image = ((System.Drawing.Image)(resources.GetObject("pbCacto2.Image")));
            this.pbCacto2.Location = new System.Drawing.Point(1052, 284);
            this.pbCacto2.Name = "pbCacto2";
            this.pbCacto2.Size = new System.Drawing.Size(95, 72);
            this.pbCacto2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbCacto2.TabIndex = 5;
            this.pbCacto2.TabStop = false;
            // 
            // contador
            // 
            this.contador.Tick += new System.EventHandler(this.contador_Tick);
            // 
            // timer_colisao
            // 
            this.timer_colisao.Enabled = true;
            this.timer_colisao.Interval = 10;
            this.timer_colisao.Tick += new System.EventHandler(this.timer_colisao_Tick);
            // 
            // timer_nuvens
            // 
            this.timer_nuvens.Interval = 13;
            this.timer_nuvens.Tick += new System.EventHandler(this.timer_nuvens_Tick);
            // 
            // pb_nuvem_1
            // 
            this.pb_nuvem_1.Image = ((System.Drawing.Image)(resources.GetObject("pb_nuvem_1.Image")));
            this.pb_nuvem_1.Location = new System.Drawing.Point(542, 55);
            this.pb_nuvem_1.Name = "pb_nuvem_1";
            this.pb_nuvem_1.Size = new System.Drawing.Size(100, 35);
            this.pb_nuvem_1.TabIndex = 7;
            this.pb_nuvem_1.TabStop = false;
            // 
            // pb_nuvem_3
            // 
            this.pb_nuvem_3.Image = ((System.Drawing.Image)(resources.GetObject("pb_nuvem_3.Image")));
            this.pb_nuvem_3.Location = new System.Drawing.Point(1094, 206);
            this.pb_nuvem_3.Name = "pb_nuvem_3";
            this.pb_nuvem_3.Size = new System.Drawing.Size(100, 35);
            this.pb_nuvem_3.TabIndex = 8;
            this.pb_nuvem_3.TabStop = false;
            // 
            // pb_nuvem_2
            // 
            this.pb_nuvem_2.Image = ((System.Drawing.Image)(resources.GetObject("pb_nuvem_2.Image")));
            this.pb_nuvem_2.Location = new System.Drawing.Point(886, 113);
            this.pb_nuvem_2.Name = "pb_nuvem_2";
            this.pb_nuvem_2.Size = new System.Drawing.Size(100, 35);
            this.pb_nuvem_2.TabIndex = 9;
            this.pb_nuvem_2.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Engravers MT", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(116, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 19);
            this.label1.TabIndex = 10;
            this.label1.Text = "label1";
            // 
            // pb_passaro
            // 
            this.pb_passaro.Image = ((System.Drawing.Image)(resources.GetObject("pb_passaro.Image")));
            this.pb_passaro.Location = new System.Drawing.Point(1325, 266);
            this.pb_passaro.Name = "pb_passaro";
            this.pb_passaro.Size = new System.Drawing.Size(47, 35);
            this.pb_passaro.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pb_passaro.TabIndex = 11;
            this.pb_passaro.TabStop = false;
            // 
            // timer_passaros
            // 
            this.timer_passaros.Interval = 13;
            this.timer_passaros.Tick += new System.EventHandler(this.timer_passaros_Tick);
            // 
            // pb_restart
            // 
            this.pb_restart.Location = new System.Drawing.Point(424, 163);
            this.pb_restart.Name = "pb_restart";
            this.pb_restart.Size = new System.Drawing.Size(113, 78);
            this.pb_restart.TabIndex = 12;
            this.pb_restart.TabStop = false;
            this.pb_restart.Visible = false;
            this.pb_restart.Click += new System.EventHandler(this.pb_restart_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Engravers MT", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(2, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(108, 19);
            this.label2.TabIndex = 13;
            this.label2.Text = "Pontos:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1384, 490);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.pb_restart);
            this.Controls.Add(this.pb_passaro);
            this.Controls.Add(this.pbchao_2);
            this.Controls.Add(this.pbchao_1);
            this.Controls.Add(this.pb_dino_abaixado);
            this.Controls.Add(this.pb_dino_pe);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pbCacto2);
            this.Controls.Add(this.pbCacto);
            this.Controls.Add(this.pb_nuvem_1);
            this.Controls.Add(this.pb_nuvem_2);
            this.Controls.Add(this.pb_nuvem_3);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.pbchao_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbchao_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_dino_pe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_dino_abaixado)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCacto)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbCacto2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_nuvem_1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_nuvem_3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_nuvem_2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_passaro)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pb_restart)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer timer_velocidade_chao;
        private System.Windows.Forms.Timer timer_movimento_dino;
        private System.Windows.Forms.Timer timer_descer;
        private System.Windows.Forms.Timer timer_pulo;
        private System.Windows.Forms.Timer timer_parado_alto;
        private System.Windows.Forms.Timer Cactos;
        private System.Windows.Forms.PictureBox pbchao_1;
        private System.Windows.Forms.PictureBox pbchao_2;
        private System.Windows.Forms.PictureBox pb_dino_pe;
        private System.Windows.Forms.PictureBox pb_dino_abaixado;
        private System.Windows.Forms.PictureBox pbCacto;
        private System.Windows.Forms.PictureBox pbCacto2;
        private System.Windows.Forms.Timer contador;
        private System.Windows.Forms.Timer timer_colisao;
        private System.Windows.Forms.Timer timer_nuvens;
        private System.Windows.Forms.PictureBox pb_nuvem_1;
        private System.Windows.Forms.PictureBox pb_nuvem_3;
        private System.Windows.Forms.PictureBox pb_nuvem_2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pb_passaro;
        private System.Windows.Forms.Timer timer_passaros;
        private System.Windows.Forms.PictureBox pb_restart;
        private System.Windows.Forms.Label label2;
    }
}

